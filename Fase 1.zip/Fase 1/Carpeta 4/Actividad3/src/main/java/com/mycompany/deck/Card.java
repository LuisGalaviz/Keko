package com.mycompany.deck;

import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;
import java.util.*;



public class Card {
    private String Palo;
    private String Color;
    private String Valor;

    public Card(String Palo, String Color, String Valor) {
        this.Palo = Palo;
        this.Color = Color;
        this.Valor = Valor;
    }

    @Override
    public String toString() {
        return Palo + "," + Color + "," + Valor;
    }
}
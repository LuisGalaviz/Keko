package com.mycompany.deck;

public class Actividad3 {
    public static void main(String[] args) {
        Deck miDeck = new Deck();

        miDeck.Usuario();
    }
}

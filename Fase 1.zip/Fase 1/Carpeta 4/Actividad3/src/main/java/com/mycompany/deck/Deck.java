package com.mycompany.deck;

import java.util.Collections;
import java.util.LinkedList;
import java.util.Random;
import java.util.Scanner;

public class Deck {
    private LinkedList<Card> cartas;

    public Deck() {
        cartas = new LinkedList<>();
        String[] Palos = {"Treboles", "Corazones", "Picas", "Diamantes"};
        String[] Valores = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "A", "J", "Q", "K"};

        for (String Palo : Palos) {
            String Color = (Palo.equals("Corazones") || Palo.equals("Diamantes")) ? "Rojo" : "Negro";
            for (String Valor : Valores) {
                cartas.add(new Card(Palo, Color, Valor));
            }
        }
    }
    
    public void Usuario() {
        Scanner entrada = new Scanner(System.in);
        
        System.out.println("Que deseas realiza?");
        System.out.println("1. Mezclar");
        System.out.println("2. Mostrar primera carta");
        System.out.println("3. Mostrar carta alazar");
        System.out.println("4. Tomar 5 cartas");
        System.out.println("5. Finalizar");
        System.out.println();
        
        System.out.print("Selecciona una opcion: ");
        int num = entrada.nextInt();
        System.out.println();
        
        switch (num) {
            case 1: 
                System.out.println("-----------------------------");
                shuffle();
                break;
            case 2: 
                System.out.println("-----------------------------");
                head();
                break;
            case 3: 
                System.out.println("-----------------------------");
                pick();
                break;
            case 4: 
                System.out.println("-----------------------------");
                hand();
                break;
            case 5: 
                System.out.println("-----------------------------");
                end();
                break;
        }
        
    }
    

    public void shuffle() {
    inicializarCartas(); 
    Collections.shuffle(cartas);
    System.out.println("Se mezclo el Deck.");
    System.out.println("-----------------------------");
    Usuario();
}

    
    private void inicializarCartas() {
    cartas.clear(); // Limpia el deck actual
    String[] Palos = {"Treboles", "Corazones", "Picas", "Diamantes"};
    String[] Valores = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "A", "J", "Q", "K"};

    for (String Palo : Palos) {
        String Color = (Palo.equals("Corazones") || Palo.equals("Diamantes")) ? "Rojo" : "Negro";
        for (String Valor : Valores) {
            cartas.add(new Card(Palo, Color, Valor));
        }
    }
}


    public void head() {
        if (!cartas.isEmpty()) {
            Card carta = cartas.removeFirst();
            System.out.println(carta);
            System.out.println("Quedan " + cartas.size() + " cartas en deck.");
            System.out.println("-----------------------------");
        } else {
            System.out.println("El deck está vacío.");
            System.out.println("-----------------------------");
        }
        Usuario();
    }

    public void pick() {
        if (!cartas.isEmpty()) {
            Random random = new Random();
            int index = random.nextInt(cartas.size());
            Card carta = cartas.remove(index);
            System.out.println(carta);
            System.out.println("Quedan " + cartas.size() + " cartas en deck.");
            System.out.println("-----------------------------");
        } else {
            System.out.println("El deck está vacío.");
            System.out.println("-----------------------------");
        }
        Usuario();
    }

    public void hand() {
        if (cartas.size() >= 5) {
            for (int i = 0; i < 5; i++) {
                Card carta = cartas.removeFirst();
                System.out.println(carta);
            }
            System.out.println("Quedan " + cartas.size() + " cartas en deck.");
            System.out.println("-----------------------------");
        } else {
            System.out.println("No hay suficientes cartas en el deck.");
            System.out.println("-----------------------------");
        }
        Usuario();
    }
    
    public void end() {
        System.out.println("Hasta pronto!");
        System.exit(0);
    }
}

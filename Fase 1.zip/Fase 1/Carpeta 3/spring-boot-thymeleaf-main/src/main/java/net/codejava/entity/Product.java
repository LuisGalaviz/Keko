package net.codejava.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Product {

    private Long id;
    private String name;
    private int edad;
    private String sexo;
    private double estatura;
    private double peso;
    private double imc;

    public Product() {
    }

    protected Product(Long id, String name, int edad, String sexo, double estatura, double peso, double imc) {
        super();
        this.id = id;
        this.name = name;
        this.edad = edad;
        this.sexo = sexo;
        this.estatura = estatura;
        this.peso = peso;
        this.imc = imc;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
    this.id = id;
}

public String getName() {
    return name;
}

public void setName(String name) {
    this.name = name;
}

public int getEdad() {
    return edad;
}

public void setEdad(int edad) {
    this.edad = edad;
}

public String getSexo() {
    return sexo;
}

public void setSexo(String sexo) {
    this.sexo = sexo;
}

public double getEstatura() {
    return estatura;
}

public void setEstatura(double estatura) {
    this.estatura = estatura;
}

public double getPeso() {
    return peso;
}

public void setPeso(double peso) {
    this.peso = peso;
}

public double getImc() {
    if (estatura > 0) {
        this.imc = peso / (estatura * estatura);
    } else {
        this.imc = 0;
    }
    return this.imc;
}

public void setImc(double imc) {
    this.imc = imc;
}
    
}
package net.codejava.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/example")
public class RestApiController {

    @GetMapping("/hello")
    public String hello() {
        return "¡Hola desde el REST controller!";
    }

    @GetMapping("/saludo/{nombre}")
    public String saludo(@PathVariable String nombre) {
        return "Hola, " + nombre + "!";
    }
}